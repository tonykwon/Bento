<h2>Build an Empire</h2>

<p>
    You've made a good decision in installing +Bento.
    We'll let you get right to building your empire. 
    The links on the left hand side will help you. 
    We recommend you start by logging in.
</p>

<h4>Examples</h4>

<h4>Standard CMS Pages</h4>
        
<ul>
    <li><!--scms:link:login--></li>
    <li><!--scms:link:logout--></li>
    <li><!--scms:link:account--></li>
    <li><!--scms:link:forgot--></li>
    <li><!--scms:link:reset--></li>
    <li><!--scms:link:register--></li>
    <li><!--scms:link:search--></li>
    <li><!--scms:link:admin--></li>
    <li><!--scms:link:error--></li>
</ul>