<p>
	This is the default help page. It loads if no better topic search is found.
    If you wish to edit it, you can find it here. 
</p>

<hr class="space">

<pre><?php echo "/page/help/" . strtolower($this->is_language()) . "/help.php";?></pre>