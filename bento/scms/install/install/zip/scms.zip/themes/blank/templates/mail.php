<?
//-------------------------------------------------------------------------------//
//
//	Table of Contents
//
//-------------------------------------------------------------------------------//
// Class
class scms_mail {

	// Load the variables 
	public $public;
	public $private;
	
	// Let's add the default css
	public function __construct(){} 

// class
}
//-------------------------------------------------------------------------------//	