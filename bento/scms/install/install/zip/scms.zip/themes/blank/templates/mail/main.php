<!DOCTYPE html>
<html xml:lang="<!--scms:language-->" lang="<!--scms:language-->">
<head></head>
<body>

<div style="
	border: 1px solid #222;
    -moz-box-shadow: 0 0 5px #111;
    -webkit-box-shadow: 0 0 5px#111;
    box-shadow: 0 0 5px #111;
	">

    <div style="
        background-color: #222; 
        padding: 10px;
        background-color: #222222;
        background-repeat: repeat-x;
        background-image: -khtml-gradient(linear, left top, left bottom, from(#333333), to(#222222));
        background-image: -moz-linear-gradient(top, #333333, #222222);
        background-image: -ms-linear-gradient(top, #333333, #222222);
        background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #333333), color-stop(100%, #222222));
        background-image: -webkit-linear-gradient(top, #333333, #222222);
        background-image: -o-linear-gradient(top, #333333, #222222);
        background-image: linear-gradient(top, #333333, #222222);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#333333', endColorstr='#222222', GradientType=0);
        -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25), inset 0 -1px 0 rgba(0, 0, 0, 0.1);
        -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25), inset 0 -1px 0 rgba(0, 0, 0, 0.1);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25), inset 0 -1px 0 rgba(0, 0, 0, 0.1);">
    
        <h1 style="color: #00BD39; padding: 0; margin: 0; font-size: 18px; font-weight:normal;">bento</h1>
    
    </div>
    
    <div style="margin-bottom: 50px; padding: 10px;">
        
		<!--scms:page-->  
    
    </div>

    <div style="
    	color: #FFF;
    	background-color: #222; 
        padding: 10px;
        background-color: #222222;
        background-repeat: repeat-x;
        background-image: -khtml-gradient(linear, left top, left bottom, from(#333333), to(#222222));
        background-image: -moz-linear-gradient(top, #333333, #222222);
        background-image: -ms-linear-gradient(top, #333333, #222222);
        background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #333333), color-stop(100%, #222222));
        background-image: -webkit-linear-gradient(top, #333333, #222222);
        background-image: -o-linear-gradient(top, #333333, #222222);
        background-image: linear-gradient(top, #333333, #222222);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#333333', endColorstr='#222222', GradientType=0);
        -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25), inset 0 -1px 0 rgba(0, 0, 0, 0.1);
        -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25), inset 0 -1px 0 rgba(0, 0, 0, 0.1);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25), inset 0 -1px 0 rgba(0, 0, 0, 0.1);
        ">
    
        <p>All Rights Reserved <? echo $_SERVER['HTTP_HOST'];?> &copy;<? echo date("Y")?></p> 
    
    </div> 

</div>

</body>
</html>