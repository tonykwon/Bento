<p>Thanks for taking the time to install bento. Now it's time to build your empire.</p>

<p><a href="<? echo $_SERVER['HTTP_HOST'];?>">Get Started</a></p>