<p>Welcome to builtonbento.com. We just need you to complete the following step and your account will be setup!</p>

<p><a href="<!--scms:mail:variable:url-->">Confirm your account</a></p>