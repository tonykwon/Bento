<p>Looks like you forgot your password. No problemo, just follow the following link to reset it.</p>

<p><a href="<!--scms:mail:variable:url-->">Reset Your Password</a></p>