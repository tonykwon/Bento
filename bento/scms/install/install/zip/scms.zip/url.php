<?
/*
@class: scms_url
@description: Creates custom urls for scms
@params:
*/
class scms_url {

	// Load the variables 
	public $public;
	public $private;
	
	public function __construct() {} 

// class
}
?>