<?php 
/*
@class: scms_handler
@description: The controller class for the scms plugin
@params:
@shortcode:  
@return:
*/
class scms_handler extends handler {

	// Load the variables 
	public $public;
	public $private;
	
	public function __construct() {} 

// class
}
?>