<?
/*
@class: scms_feed
@description: Control class for feeds in scms
@params:
*/
class scms_feed {

	// Load the variables 
	public $public;
	public $private;
	
	// Will load for all xhr requests
	public function __constuct(){}
	
	// Will load for the home page
	public function home(){} 
	
// class
} ?>