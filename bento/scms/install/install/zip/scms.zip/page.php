<?
/*
@class: scms_page
@description: Page specific functions (model in the mvc)
@params:
*/
class scms_page {

	// Load the variables 
	public $public;
	public $private;
	
	public function __construct() {} 

	// Check this out
	public function home(){

		// This will setup data, if we have an app running
		return array("message"	=>	"Welcome to Bento!");
		
	// if	
	}

// class
}
?>