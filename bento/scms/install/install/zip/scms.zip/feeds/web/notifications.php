<li>
	<a href="<!--scms:feed:url-->">
    	<!--scms:feed:message--><br />
    	<small><!--scms:feed:time--></small>
    </a>
</li>